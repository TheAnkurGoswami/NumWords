
NumWords module converts numbers from their numerical form to their international semantic form.
Current input limit is 10<sup>66</sup>-1.

Usage:

```python
import numwords
numwords.numwords(12345)
```
```python
>>> "Twelve Thousand Three Hundred Fourty Five"
```
