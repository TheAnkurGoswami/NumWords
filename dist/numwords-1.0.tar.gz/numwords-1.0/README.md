# NumWords

NumWords module converts numbers from their numerical form to their international semantic form.

Script by अंkur गोswami
